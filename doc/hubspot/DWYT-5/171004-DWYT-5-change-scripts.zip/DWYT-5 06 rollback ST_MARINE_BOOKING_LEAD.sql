/*
    DWYT-5 Rollback create table NEPTUNE_Stage.dbo.ST_MARINE_BOOKING_LEAD
    26/09/2017  TW  New script
*/

USE [NEPTUNE_Stage]
GO

IF OBJECT_ID('dbo.ST_MARINE_BOOKING_LEAD', 'U') IS NOT NULL
    DROP TABLE [dbo].[ST_MARINE_BOOKING_LEAD]
GO
