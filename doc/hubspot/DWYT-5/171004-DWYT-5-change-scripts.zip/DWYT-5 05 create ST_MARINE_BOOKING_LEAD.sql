/*
    DWYT-5 Create table NEPTUNE_Stage.dbo.ST_MARINE_BOOKING_LEAD
    26/09/2017  TW  New script
*/

USE [NEPTUNE_Stage]
GO

IF OBJECT_ID('dbo.ST_MARINE_BOOKING_LEAD', 'U') IS NOT NULL
    DROP TABLE [dbo].[ST_MARINE_BOOKING_LEAD]
GO

CREATE TABLE [dbo].[ST_MARINE_BOOKING_LEAD](
     [Source_Key] [varchar](50) NULL
    ,[BookRef] [varchar](50) NULL
    ,[ClientCode] [varchar](50) NULL
    ,[BookingType] [varchar](30) NULL
    ,[BookedBy] [varchar](50) NULL
    ,[BookingSourcePrimary] [varchar](50) NULL
    ,[BookingDate] [datetime] NULL
    ,[CancelledDate] [datetime] NULL
    ,[DepartureDate] [datetime] NULL
    ,[ConfirmDate] [datetime] NULL
    ,[Status] [varchar](30) NULL
    ,[TotalPax] [int] NULL
    ,[Duration] [int] NULL
    ,[CurrencyCode] [varchar](30) NULL
    ,[BookingOfficeLocation] [varchar](50) NULL
    ,[BookingLanguage] [varchar](10) NULL
    ,[CharterTypeName] [varchar](50) NULL
    ,[CharterTypeCode] [varchar](10) NULL
    ,[BrandName] [varchar](50) NULL
    ,[BrandCode] [varchar](10) NULL
    ,[ProductName] [varchar](50) NULL
    ,[ProductCode] [varchar](25) NULL
    ,[F_CONTACT_URN] [bigint] NULL
    ,[Title] [nvarchar](50) NULL
    ,[FirstName] [nvarchar](50) NULL
    ,[LastName] [nvarchar](50) NULL
    ,[DateOfBirth] [datetime] NULL
    ,[Nationality] [nvarchar](50) NULL
    ,[Language] [nvarchar](50) NULL
    ,[Add1] [nvarchar](50) NULL
    ,[Add2] [nvarchar](50) NULL
    ,[Add3] [nvarchar](50) NULL
    ,[City] [nvarchar](50) NULL
    ,[County] [nvarchar](50) NULL
    ,[Postcode] [nvarchar](50) NULL
    ,[Country] [nvarchar](50) NULL
    ,[ClientType] [varchar](10) NULL
    ,[Phone1] [nvarchar](50) NULL
    ,[Phone2] [nvarchar](50) NULL
    ,[MobilePhone] [nvarchar](50) NULL
    ,[MailNo] [varchar](50) NULL
    ,[Email1] [nvarchar](200) NULL
    ,[Blacklisted] [char](1) NULL
    ,[Deceased] [char](1) NULL
    ,[GoneAway] [char](1) NULL
    ,[Lead] [nvarchar](3) NULL
) ON [PRIMARY]
GO