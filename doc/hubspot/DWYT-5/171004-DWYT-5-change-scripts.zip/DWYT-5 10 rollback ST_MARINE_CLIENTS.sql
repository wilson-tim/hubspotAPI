/*
    DWYT-5 Rollback changes to table NEPTUNE_Stage.dbo.ST_MARINE_CLIENTS
    26/09/2017  TW  New script
*/

ALTER TABLE NEPTUNE_Stage.dbo.ST_MARINE_CLIENTS
DROP COLUMN F_URN bigint NULL
GO
