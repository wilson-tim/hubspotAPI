/*
    DWYT-3 Rollback changes to table NEPTUNE_Stage..ST_MARINE_CLIENT_PREFERENCE
    04/10/2017  TW  New script
*/

ALTER TABLE NEPTUNE_Stage..ST_MARINE_CLIENT_PREFERENCE
DROP COLUMN CancelFromEnews, CancelFromSMS
GO
