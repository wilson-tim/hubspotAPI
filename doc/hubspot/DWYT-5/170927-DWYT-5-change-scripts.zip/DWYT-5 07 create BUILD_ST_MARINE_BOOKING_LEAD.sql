--========================================================================================================================
-- Procedure Date - Procedure Description
-- 26-Sep-2017      BUILD_ST_MARINE_BOOKING_LEAD - Loads data into table ST_MARINE_BOOKING_LEAD
--
--========================================================================================================================
-- Change History===
--========================================================================================================================
-- Date             Version     Who                Comment
-- 26-Sep-2017      1.0         Tim Wilson         Original Version    
--
--========================================================================================================================
USE [NEPTUNE_Stage]
GO

IF OBJECT_ID('dbo.BUILD_ST_MARINE_BOOKING_LEAD', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[BUILD_ST_MARINE_BOOKING_LEAD]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[BUILD_ST_MARINE_BOOKING_LEAD] AS
BEGIN
    EXEC AMI_Galaxy.dbo.AMI_LOG_OPEN 'NPTN','ST_MAR_BKGLEAD','BUILD_ST_MARINE_BOOKING_LEAD'

    TRUNCATE TABLE 
        ST_MARINE_BOOKING_LEAD
    
    INSERT INTO 
        ST_MARINE_BOOKING_LEAD
    
    SELECT DISTINCT  
         'NPT-'+cast(ST_MARINE_FBKG.bkgref as varchar(25)) Source_Key
        ,ST_MARINE_FBKG.bkgref                             BookRef
        ,ST_MARINE_FBKG.ClientNo                           ClientCode
        ,ST_MARINE_FBKG.DirectAgent                        BookingType
        ,ST_MARINE_FBKG.optionUser                         BookedBy
        ,ST_MARINE_FBKG.BkgSrcCd                           BookingSourcePrimary
		,ST_MARINE_FBKG.ConfirmDate                        BookingDate
        ,ST_MARINE_FBKG.CancelDate                         CancelledDate
        ,ST_MARINE_FBKG.DepartureDate
        ,ST_MARINE_FBKG.ConfirmDate
        ,CASE
            WHEN ST_MARINE_FBKG.BookingStatusID IN(3,18) THEN 'Confirmed'
            WHEN ST_MARINE_FBKG.BookingStatusID IN(8,19) THEN 'Cancelled'
            WHEN ST_MARINE_FBKG.BookingStatusID IN(1,17) THEN 'N/A'
        END AS                                             [Status]
        ,ST_MARINE_FBKG.PaxNo                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          TotalPax
        ,ST_MARINE_FBKG.HolidayDuration                    Duration
        ,ST_MARINE_FBKG.Currency                           CurrencyCode
        ,ST_MARINE_FBKG.BkgLocation                        BookingOfficeLocation
        ,NEPTUNE_ORIGIN.Lang                               BookingLanguage
		
        ,ST_MARINE_FBKG.PackageDesc                        CharterTypeName
        ,ST_MARINE_FBKG.Package                            CharterTypecode
        ,CASE    
            WHEN ST_MARINE_FBKG.Brandcode='SUN' THEN 'SUNSAIL'
            WHEN ST_MARINE_FBKG.Brandcode='LBT' THEN 'LEBOAT'
            ELSE 'XXX'
        END AS                                             BrandName
        ,ST_MARINE_FBKG.BrandCode
        ,'??'                                              Productname
        ,ST_MARINE_FBKG.ProductCode
        ,NEPTUNE_BOOK.F_CONTACT_URN
        ,NEPTUNE_MAIL_CONTACT.F_title                      Title
        ,NEPTUNE_MAIL_CONTACT.F_forename                   FirstName
        ,NEPTUNE_MAIL_CONTACT.F_surname                    LastName
        -- ,NEPTUNE_FAMILY.F_DOB                              DateofBirth
        ,CASE
            WHEN ISNULL(NEPTUNE_FAMILY.F_DOB, '') = '' THEN NULL
            ELSE CONVERT(datetime,dbo.fn_CheckDate(SUBSTRING(NEPTUNE_FAMILY.F_DOB,7,4) + SUBSTRING(NEPTUNE_FAMILY.F_DOB,4,2) + SUBSTRING(NEPTUNE_FAMILY.F_DOB,1,2)),103)
         END AS DateofBirth
        ,NEPTUNE_FAMILY.F_citizen                          Nationality
        ,CASE
		    WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL THEN NEPTUNE_ORIGIN.LANG
			ELSE NULL
		 END AS                                            [Language]
        ,NEPTUNE_MAIL_CONTACT.F_addr1                      Add1
        ,NEPTUNE_MAIL_CONTACT.F_addr2                      Add2
        ,NEPTUNE_MAIL_CONTACT.F_addr3                      Add3
        ,NEPTUNE_MAIL_CONTACT.F_town                       City
        ,NEPTUNE_MAIL_CONTACT.F_county                     County
        ,NEPTUNE_MAIL_CONTACT.F_post_code                  PostCode
        ,NEPTUNE_MAIL_CONTACT.F_country                    Country
        ,NEPTUNE_MAIL_CONTACT.F_client_type                ClientType
        ,NEPTUNE_MAIL_CONTACT.F_tel1_no                    Phone1
        ,NEPTUNE_MAIL_CONTACT.F_tel2_no                    Phone2
        ,NEPTUNE_MAIL_CONTACT.F_tel3_no                    MobilePhone
        ,NEPTUNE_MAIL_CONTACT.F_mail_no                    MailNo
        ,NEPTUNE_MAIL_CONTACT.F_email                      Email
        ,CASE
		    WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL THEN 'N' 
			ELSE NULL
		 END AS                                            Blacklisted  -- Updated below
        ,CASE
		    WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL THEN 'N' 
			ELSE NULL
		 END AS                                            Deceased  -- Updated below
        ,CASE
		    WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL THEN 'N' 
			ELSE NULL
		 END AS                                            Goneaway  -- Updated below
        ,CASE
            WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL AND NEPTUNE_FAMILY.F_leader='TRUE' THEN 'Yes'
            WHEN NEPTUNE_FAMILY.F_URN IS NOT NULL AND NEPTUNE_FAMILY.F_leader!='TRUE' THEN 'No'
			ELSE NULL
		 END AS                                            Lead
    FROM 
        NEPTUNE_Stage.dbo.ST_MARINE_FBKG    ST_MARINE_FBKG
    LEFT JOIN
        NEPTUNE_Stage.dbo.NEPTUNE_BOOK    NEPTUNE_BOOK
        ON
            ST_MARINE_FBKG.bkgref=NEPTUNE_BOOK.CLIENT_NO
    LEFT JOIN
        NEPTUNE_Stage.dbo.NEPTUNE_FAMILY    NEPTUNE_FAMILY
        ON
            NEPTUNE_BOOK.F_CONTACT_URN=NEPTUNE_FAMILY.F_URN
			AND
			NEPTUNE_BOOK.F_CONTACT_URN != 0
    LEFT JOIN
        NEPTUNE_Stage.dbo.NEPTUNE_ORIGIN    NEPTUNE_ORIGIN
        ON
            NEPTUNE_BOOK.LANGUAGE=NEPTUNE_ORIGIN.ORIGIN
    LEFT OUTER JOIN
        NEPTUNE_Stage.dbo.NEPTUNE_MAIL_CONTACT    NEPTUNE_MAIL_CONTACT 
        ON 
            NEPTUNE_FAMILY.F_mail_no = NEPTUNE_MAIL_CONTACT.F_mail_no
    ORDER BY 
        bkgref
		
    UPDATE ST_MARINE_BOOKING_LEAD    
        SET 
            Blacklisted='Y'
        FROM 
            ST_MARINE_BOOKING_LEAD
        INNER JOIN
            NEPTUNE_MAIL_CONTACT
            ON
                CLIENTCODE=F_mail_no
        WHERE 
            F_client_category='Z'
			AND
			Blacklisted IS NOT NULL
        
    UPDATE ST_MARINE_BOOKING_LEAD
        SET 
            Deceased='Y'
        FROM 
            ST_MARINE_BOOKING_LEAD
        INNER JOIN
            NEPTUNE_MAIL_CONTACT
            ON
                CLIENTCODE=F_mail_no
        WHERE 
            F_client_category='x'
			AND
			Deceased IS NOT NULL

    UPDATE ST_MARINE_BOOKING_LEAD
        SET 
            Goneaway='Y'
        FROM 
            ST_MARINE_BOOKING_LEAD
        INNER JOIN
            NEPTUNE_MAIL_CONTACT
            ON
                CLIENTCODE=F_mail_no
        WHERE 
            F_client_category='GAS'
  			AND
			Goneaway IS NOT NULL
  
    EXEC AMI_Galaxy.dbo.AMI_LOG_CLOSE 'NPTN','ST_MAR_BKGLEAD'
END
GO