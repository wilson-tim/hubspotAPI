/*
    DWYT-5 Rollback changes to table NEPTUNE_Stage.dbo.ST_MARINE_BOOKINGS
 
    25/09/2017  TW  New script
*/

ALTER TABLE NEPTUNE_Stage.dbo.ST_MARINE_BOOKINGS
DROP COLUMN F_CONTACT_URN
GO
