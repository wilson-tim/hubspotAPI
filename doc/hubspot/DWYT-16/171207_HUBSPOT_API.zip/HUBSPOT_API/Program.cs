﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Web.Script.Serialization;
using System.Net.Http.Headers;
using System.Configuration;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;

namespace HUBSPOT_API
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if (args.Count() == 2)
                {
                    string brand = args[0].ToString();
                    string module = args[1].ToString();
                    string storedProcedureName = "";
                    Contact objContact = new Contact();

                    if (brand == "DEV")
                    {
                        if (module == "ENEWS")
                            objContact.CreateOrUpdateContact(brand, "BUILD_HUBSPOT_TRITON_SS_ENEWS").Wait();
                        if (module == "BROCREQ")
                            objContact.CreateOrUpdateContact(brand, "BUILD_HUBSPOT_TRITON_SS_BROCHURE_REQUESTS").Wait();
                        if (module == "QUOTES")
                            objContact.CreateOrUpdateContact(brand, "BUILD_HUBSPOT_TRITON_SS_QUOTES").Wait();
                        if (module == "BOOKINGS")
                            objContact.CreateOrUpdateContact(brand,"BUILD_HUBSPOT_TRITON_SS_BOOKINGS").Wait();
                        if (module == "LEBOAT" || module == "SUNSAIL" || module == "MOORINGS")
                            objContact.SyncContactProperties(module).Wait();
                    }
                    if (brand == "LEBOAT")
                    {
                        if (module == "ENEWS")
                            storedProcedureName = "BUILD_HUBSPOT_NEPTUNE_ENEWS";
                        if (module == "BROCREQ")
                            storedProcedureName = "BUILD_HUBSPOT_NEPTUNE_BROCHURE_REQUESTS";
                        if (module == "QUOTES")
                            storedProcedureName = "BUILD_HUBSPOT_NEPTUNE_QUOTES";
                        if (module == "BOOKINGS")
                            storedProcedureName = "BUILD_HUBSPOT_NEPTUNE_BOOKINGS";

                        objContact.CreateOrUpdateContact(brand, storedProcedureName).Wait();
                    }
                    if (brand == "SUNSAIL")
                    {
                        if (module == "ENEWS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_SS_ENEWS";
                        if (module == "BROCREQ")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_SS_BROCHURE_REQUESTS";
                        if (module == "QUOTES")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_SS_QUOTES";
                        if (module == "BOOKINGS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_SS_BOOKINGS";

                        objContact.CreateOrUpdateContact(brand, storedProcedureName).Wait();
                    }
                    if (brand == "MOORINGS")
                    {
                        if (module == "ENEWS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_TM_ENEWS";
                        if (module == "BROCREQ")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_TM_BROCHURE_REQUESTS";
                        if (module == "QUOTES")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_TM_QUOTES";
                        if (module == "BOOKINGS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_TM_BOOKINGS";

                        objContact.CreateOrUpdateContact(brand, storedProcedureName).Wait();
                    }
                    if (brand == "FOOTLOOSE")
                    {
                        if (module == "ENEWS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_FL_ENEWS";
                        if (module == "BROCREQ")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_FL_BROCHURE_REQUESTS";
                        if (module == "QUOTES")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_FL_QUOTES";
                        if (module == "BOOKINGS")
                            storedProcedureName = "BUILD_HUBSPOT_TRITON_FL_BOOKINGS";

                        objContact.CreateOrUpdateContact(brand, storedProcedureName).Wait();
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Number of arguments");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
