USE [HUBSPOT]
GO
/****** Object:  UserDefinedDataType [dbo].[HugeMoney]    Script Date: 01/12/2017 09:14:49 ******/
CREATE TYPE [dbo].[HugeMoney] FROM [decimal](28, 4) NULL
GO
